package com.example.chimeraapp4;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class TableViewAdapter extends RecyclerView.Adapter
{
    private Context context;
    MainActivity mainactivity;
    private List<ComponentModal> componentList;
    //int position;
    /*private ArrayList component_id,component_name,component_price,component_nos,total;

    TableViewAdapter(Context context,ArrayList component_id,ArrayList component_name,ArrayList component_price,ArrayList component_nos,ArrayList total)
    {
        this.context=context;
        this.component_id=component_id;
        this.component_name=component_name;
        this.component_price=component_price;
        this.component_nos=component_nos;
        this.total=total;
    }*/
    TableViewAdapter(MainActivity mainactivity, Context context, List<ComponentModal> componentList)
    {
        this.mainactivity=mainactivity;
        this.context= context;
        this.componentList = componentList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        //LayoutInflater inflater= LayoutInflater.from(context);
        //View view=inflater.inflate(R.layout.component_table_list,parent,false);
        //return  new RowViewHolder(view);

        View itemView = LayoutInflater.
                from(context).
                inflate(R.layout.component_table_list, parent, false);
        return new RowViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position)
    {
        //this.position=position;
        final RowViewHolder rowViewHolder=(RowViewHolder) holder;
        final int rowPos=rowViewHolder.getAdapterPosition();

        if(rowPos==0)
        {
            //Header Cells. Main Headings Appear Here

            rowViewHolder.component_id_txt.setBackgroundResource(R.drawable.table_header_cell_bg);
            rowViewHolder.component_name_txt.setBackgroundResource(R.drawable.table_header_cell_bg);
            rowViewHolder.component_price_txt.setBackgroundResource(R.drawable.table_header_cell_bg);
            rowViewHolder.component_nos_txt.setBackgroundResource(R.drawable.table_header_cell_bg);
            rowViewHolder.total_txt.setBackgroundResource(R.drawable.table_header_cell_bg);


            rowViewHolder.component_id_txt.setText("ID");
            rowViewHolder.component_name_txt.setText("Name");
            rowViewHolder.component_price_txt.setText("Price");
            rowViewHolder.component_nos_txt.setText("Nos");
            rowViewHolder.total_txt.setText("Total");
        }
        else
        {
            final ComponentModal modal = componentList.get(rowPos-1);
            rowViewHolder.component_id_txt.setBackgroundResource(R.drawable.table_content_cell_bg);
            rowViewHolder.component_name_txt.setBackgroundResource(R.drawable.table_content_cell_bg);
            rowViewHolder.component_price_txt.setBackgroundResource(R.drawable.table_content_cell_bg);
            rowViewHolder.component_nos_txt.setBackgroundResource(R.drawable.table_content_cell_bg);
            rowViewHolder.total_txt.setBackgroundResource(R.drawable.table_content_cell_bg);

            rowViewHolder.component_id_txt.setText(modal.getcomponentId()+"");
            rowViewHolder.component_name_txt.setText(modal.getcomponentName());
            rowViewHolder.component_price_txt.setText(modal.getcomponentPrice()+"");
            rowViewHolder.component_nos_txt.setText(modal.getcomponentNos()+"");
            rowViewHolder.total_txt.setText(modal.gettotal()+"");

            rowViewHolder.mainLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view)
                {
                    Intent intent=new Intent(context, UpdateActivity.class);
                    intent.putExtra("com.example.chimeraapp3.Component_List",componentList.get(rowPos-1));
                    mainactivity.startActivityForResult(intent,1);
                }
            });
        }
    }

    @Override
    public int getItemCount()
    {
        return componentList.size()+1; // one more to add header row
    }

    public class RowViewHolder extends RecyclerView.ViewHolder
    {

        LinearLayout mainLayout;
        TextView component_id_txt,component_name_txt,component_price_txt,component_nos_txt,total_txt;
        public RowViewHolder(@NonNull View itemView)
        {
            super(itemView);
            component_id_txt=itemView.findViewById(R.id.componentId);
            component_name_txt=itemView.findViewById(R.id.componentName);
            component_price_txt=itemView.findViewById(R.id.componentPrice);
            component_nos_txt=itemView.findViewById(R.id.componentNos);
            total_txt=itemView.findViewById(R.id.total);
            mainLayout=itemView.findViewById(R.id.mainLayout);
        }
    }
}
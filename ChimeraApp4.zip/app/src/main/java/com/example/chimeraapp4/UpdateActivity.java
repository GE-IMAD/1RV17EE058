package com.example.chimeraapp4;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class UpdateActivity extends AppCompatActivity {

    int componentId,componentPrice,componentNos,total;
    String componentName,componentId2,componentPrice2,componentNos2;
    TextView componentId_input2;
    EditText componentName_input2,componentPrice_input2,componentNos_input2;
    Button update_button,delete_button;
    MainActivity instance= new MainActivity();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        componentId_input2=findViewById(R.id.ID_input2);
        componentName_input2=findViewById(R.id.componentName_input2);
        componentPrice_input2=findViewById(R.id.componentPrice_input2);
        componentNos_input2=findViewById(R.id.componentNos_input2);
        update_button=findViewById(R.id.update_button);
        delete_button=findViewById(R.id.delete_button);
        //First we call this
        getAndSetIntentData();
        //Set ActionBar title after getAndSetIntentData method
        //Set the title dynamically with the component Name
        ActionBar ab= getSupportActionBar();
        if(ab!=null)
        {
            ab.setTitle(componentName);
        }
        update_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {

                // And then only we call this
                componentName= String.valueOf(componentName_input2.getText());
                componentPrice=Integer.parseInt(String.valueOf(componentPrice_input2.getText()));
                componentNos=Integer.parseInt(String.valueOf(componentNos_input2.getText()));
                total=componentPrice*componentNos;
                //MyDatabaseHelper myDB=new MyDatabaseHelper(UpdateActivity.this);
                //myDB.updateData(componentId2,componentName,componentPrice,componentNos);


                HashMap<String, String> params = new HashMap<>();
                params.put("Id", componentId2);
                params.put("ComponentName", componentName);
                params.put("ComponentPrice", String.valueOf(componentPrice));
                params.put("ComponentNos", String.valueOf(componentNos));
                params.put("Total", String.valueOf(total));

                PerformNetworkRequest request = new PerformNetworkRequest(Api.URL_UPDATE_COMPONENT, params, Api.CODE_POST_REQUEST);
                request.delegate=instance;
                request.execute();
            }
        });

        delete_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                confirmDeleteDialog();
            }
        });
    }

    void getAndSetIntentData()
    {

        if(getIntent().hasExtra("com.example.chimeraapp3.Component_List"))
        {
            //Getting data from Intent
            Intent intent=getIntent();
            ComponentModal componentList=intent.getParcelableExtra("com.example.chimeraapp3.Component_List");
            assert componentList != null;
            componentId=componentList.getcomponentId();
            componentName=componentList.getcomponentName();
            componentPrice=componentList.getcomponentPrice();
            componentNos=componentList.getcomponentNos();
            total=componentList.gettotal();
            componentId2=Integer.toString(componentId);
            componentPrice2=Integer.toString(componentPrice);
            componentNos2=Integer.toString(componentNos);
            //total=componentPrice*componentNos;
            //total2=Integer.toString(total);

            //Setting Intent data
            //componentName_input2.setText((CharSequence) componentList.get(1));
            //componentPrice_input2.setText((CharSequence) componentList.get(2));
            //componentNos_input2.setText((CharSequence) componentList.get(3));
            componentId_input2.setText(componentId2);
            componentName_input2.setText(componentName);
            componentPrice_input2.setText(componentPrice2);
            componentNos_input2.setText(componentNos2);

            if (TextUtils.isEmpty(componentName)) {
                componentName_input2.setError("Please enter name");
                componentName_input2.requestFocus();
                return;
            }

            if (TextUtils.isEmpty(componentPrice2)) {
                componentPrice_input2.setError("Please enter name");
                componentPrice_input2.requestFocus();
                return;
            }

            if (TextUtils.isEmpty(componentNos2)) {
                componentNos_input2.setError("Please enter name");
                componentNos_input2.requestFocus();
                return;
            }
        }
        else
        {
            Toast.makeText(this,"No data",Toast.LENGTH_SHORT).show();
        }
    }

    void confirmDeleteDialog()
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setTitle("Delete "+componentName+ " ?");
        builder.setMessage("Are you sure you want to delete "+componentName+" ?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i)
            {
                //MyDatabaseHelper myDB= new MyDatabaseHelper(UpdateActivity.this);
                //myDB.deleteOneRow(componentId2);
                //finish();
                PerformNetworkRequest request = new PerformNetworkRequest(Api.URL_DELETE_COMPONENT + componentId2, null, Api.CODE_GET_REQUEST);
                request.delegate=instance;
                request.execute();
            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i)
            {

            }
        });
        builder.create().show();
    }

}
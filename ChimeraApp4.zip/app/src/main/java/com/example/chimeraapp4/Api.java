package com.example.chimeraapp4;

public class Api {

    private static final String ROOT_URL = "http://192.168.1.33/InventoryApi/Api.php?apicall=";

    public static final String URL_CREATE_COMPONENT = ROOT_URL + "createcomponent";
    public static final String URL_READ_COMPONENT = ROOT_URL + "getcomponent";
    public static final String URL_UPDATE_COMPONENT = ROOT_URL + "updatecomponent";
    public static final String URL_DELETE_COMPONENT = ROOT_URL + "deletecomponent&Id=";
    public static final String URL_DELETE_ALL_COMPONENTS = ROOT_URL + "deleteallcomponents";
    public static final int CODE_GET_REQUEST = 1024;
    public static final int CODE_POST_REQUEST = 1025;

}
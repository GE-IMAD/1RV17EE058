package com.example.chimeraapp4;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.HashMap;

public class AddComponent extends AppCompatActivity
{

    EditText componentName_input;
    EditText componentPrice_input;
    EditText componentNos_input;
    Button addButton;
    //Activity activity=getParent();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_component);

        Intent intent=getIntent();

        componentName_input=findViewById(R.id.componentName_input);
        componentPrice_input=findViewById(R.id.componentPrice_input);
        componentNos_input=findViewById(R.id.componentNos_input);
        addButton=findViewById(R.id.add_button);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                //MyDatabaseHelper mydb= new MyDatabaseHelper(AddComponent.this);
                //mydb.addComponent(componentName_input.getText().toString().trim(),
                       // Integer.valueOf(componentPrice_input.getText().toString().trim()),
                       // Integer.valueOf(componentNos_input.getText().toString().trim()));*/

                createComponent();

            }
        });

    }

    private void createComponent()
    {
        String componentName = componentName_input.getText().toString().trim();
        String componentPrice = componentPrice_input.getText().toString().trim();
        int price=Integer.parseInt(componentPrice);
        String componentNos=componentNos_input.getText().toString().trim();
        int nos=Integer.parseInt(componentNos);
        int total=price*nos;

        //validating the inputs
        if (TextUtils.isEmpty(componentName)) {
            componentName_input.setError("Please enter component name");
            componentName_input.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(componentPrice)) {
            componentPrice_input.setError("Please enter component price");
            componentPrice_input.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(componentNos)) {
            componentNos_input.setError("Please enter component nos");
            componentNos_input.requestFocus();
            return;
        }
        //if validation passes

        HashMap<String, String> params = new HashMap<>();
        params.put("ComponentName", componentName);
        params.put("ComponentPrice", componentPrice);
        params.put("ComponentNos", componentNos);
        params.put("Total", String.valueOf(total));

        //Activity activity=getParent();
        //Calling the create hero API
        PerformNetworkRequest request = new PerformNetworkRequest(Api.URL_CREATE_COMPONENT, params, Api.CODE_POST_REQUEST);
        MainActivity instance= new MainActivity();
        request.delegate=instance;
        request.execute();
    }

}


package com.example.chimeraapp4;

import android.os.Parcel;
import android.os.Parcelable;


public class ComponentModal implements Parcelable {
    private int componentId;
    private String componentName;
    private int componentPrice;
    private int componentNos;
    private int total;

    public ComponentModal(int componentId, String componentName, int componentPrice, int componentNos,int total) {

        this.componentId=componentId;
        this.componentName=componentName;
        this.componentPrice=componentPrice;
        this.componentNos=componentNos;
        this.total=total;

    }

    //When the secondary activity calls the getParcelableExtra method of the intent object to start the process.
    // This constructor is where you collect the values and set up the properties of the object
    //constructor used for parcel
    protected ComponentModal(Parcel parcel) {
        componentId = parcel.readInt();
        componentName = parcel.readString();
        componentPrice = parcel.readInt();
        componentNos = parcel.readInt();
        total = parcel.readInt();
    }


    //used when unparceling our parcel (creating the object)
    public static final Creator<ComponentModal> CREATOR = new Creator<ComponentModal>() {
        @Override
        public ComponentModal createFromParcel(Parcel parcel) {
            return new ComponentModal(parcel);
        }

        @Override
        public ComponentModal[] newArray(int size) {
            return new ComponentModal[size];
        }
    };

    public int getcomponentId() {
        return componentId;
    }

    public void setcomponentId(int componentId) {
        this.componentId=componentId;
    }

    public String getcomponentName() {
        return componentName;
    }

    public void setcomponentName(String componentName) {
        this.componentName=componentName;
    }

    public int getcomponentPrice() {
        return componentPrice;
    }

    public void setcomponentPrice(int componentPrice) {
        this.componentPrice = componentPrice;
    }

    public int getcomponentNos() {
        return componentNos;
    }

    public void setcomponentNos(int componentNos) {
        this.componentNos = componentNos;
    }

    public int gettotal() {
        return total;
    }

    public void settotal(int total) {
        this.total = total;
    }


    // Parceable is used to transfer an values of an object from activity to another

    //Returns the hashcode of the object
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    //write object values to parcel for storage
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeInt(componentId);
        dest.writeString(componentName);
        dest.writeInt(componentPrice);
        dest.writeInt(componentNos);
        dest.writeInt(total);
    }

}

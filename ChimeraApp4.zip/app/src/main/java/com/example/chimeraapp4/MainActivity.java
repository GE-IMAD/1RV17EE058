package com.example.chimeraapp4;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
public class MainActivity extends AppCompatActivity implements AsyncResponse {
    static RecyclerView recyclerView;
    //private Context context;
    FloatingActionButton addbutton;
    ImageView empty_imgView;
    TextView no_dataTxt;
    //MyDatabaseHelper myDB;
    //ArrayList<String> component_id,component_name,component_price,component_nos,total;
    TableViewAdapter adapter;
    List<ComponentModal> componentList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addbutton = findViewById(R.id.add_button1);
        recyclerView = findViewById(R.id.recycleView);
        empty_imgView = findViewById(R.id.no_data_img);
        no_dataTxt = findViewById(R.id.no_data_txt);
        addbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddComponent.class);
                startActivity(intent);
            }
        });

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        //myDB = new MyDatabaseHelper(MainActivity.this);
        //storeDataInArray();
        // Store the data in the arrays first (done in storeDataInArrays) and only then it is passed into the Custom Adapter and shown in the recyclerView
        //adapter= new TableViewAdapter(MainActivity.this,component_id,component_name,component_price,
        //component_nos,total);
        getComponent();
        adapter= new TableViewAdapter(MainActivity.this,this,componentList);
        recyclerView.setAdapter(adapter);
        //PerformNetworkRequest performNetworkRequest = null;
        //recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        //new MyAsyncTask(this).execute();

    }

    private void getComponent() {
        PerformNetworkRequest request = new PerformNetworkRequest(Api.URL_READ_COMPONENT, null, Api.CODE_GET_REQUEST);
        request.delegate=this;
        request.execute();
    }

   /* public static void receivedComponentList(List<ComponentModal> componentList)
    {
        adapter= new TableViewAdapter(MainActivity,this,componentList);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(adapter);
    }*/

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            recreate();
        }
    }

    //Store Data in Array
    /*private List<ComponentModal> getComponentList() {
        List<ComponentModal> componentList = new ArrayList<>();
        //component_id=new ArrayList<>();
        //component_name=new ArrayList<>();
        //component_price=new ArrayList<>();
        //component_nos=new ArrayList<>();
        //total=new ArrayList<>();

        int component_id;
        String component_name;
        int component_price;
        int component_nos;
        int total;
        Cursor cursor;
        cursor = myDB.readAllComponentData();

        //If the getcount function returns zero there is no data
        if (cursor.getCount() == 0) {
            empty_imgView.setVisibility(View.VISIBLE);
            no_dataTxt.setVisibility(View.VISIBLE);
        }
        // Cursor is moved to next method
        else {
            //Read all the data from the cursor integer number indicated the column number
            while (cursor.moveToNext()) {
                //component_id.add(cursor.getString(0));
                //component_name.add(cursor.getString(1));
                //component_price.add(cursor.getString(2));
                //component_nos.add(cursor.getString(3));
                //total.add(cursor.getString(4));
                component_id = Integer.parseInt(cursor.getString(0).trim());
                component_name = cursor.getString(1).trim();
                component_price = Integer.parseInt(cursor.getString(2).trim());
                component_nos = Integer.parseInt(cursor.getString(3).trim());
                total = Integer.parseInt(cursor.getString(4).trim());
                componentList.add(new ComponentModal(component_id, component_name, component_price, component_nos, total));
            }
            empty_imgView.setVisibility(View.GONE);
            no_dataTxt.setVisibility(View.GONE);

        }

        return componentList;
    }*/

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.my_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.delete_all) {
            Toast.makeText(this, "Delete", Toast.LENGTH_SHORT).show();
            confirmDeleteAllDialog();
        }
        return super.onOptionsItemSelected(item);
    }


    void confirmDeleteAllDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete All?");
        builder.setMessage("Are you sure you want to delete all data?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //MyDatabaseHelper myDB = new MyDatabaseHelper(MainActivity.this);
                //myDB.deleteAllData();

                PerformNetworkRequest request = new PerformNetworkRequest(Api.URL_DELETE_ALL_COMPONENTS , null, Api.CODE_GET_REQUEST);
                request.delegate=MainActivity.this;
                request.execute();
                // To avoid black screen (if any) we go from this activity to the same activity using intents after deleting all the data
                // i.e. Refresh Activity
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create().show();
    }

    @Override
    public void processFinish(JSONArray components) throws JSONException
    {
        componentList.clear();

        for (int i = 0; i < components.length(); i++)
        {
            JSONObject obj = components.getJSONObject(i);

            componentList.add(new ComponentModal(
                    obj.getInt("Id"),
                    obj.getString("ComponentName").trim(),
                    obj.getInt("ComponentPrice"),
                    obj.getInt("ComponentNos"),
                    obj.getInt("Total")
            ));
        }

        adapter= new TableViewAdapter(MainActivity.this,this,componentList);
        recyclerView.setAdapter(adapter);
    }
}